import random
import time
from datetime import datetime
from telebot import TeleBot

# Gán bot token nếu muốn dùng riêng file, hoặc truyền bot từ file chính
bot = TeleBot("YOUR_BOT_TOKEN")  # Nếu đã import từ file chính thì bỏ dòng này

# Nếu chưa có, import từ file cũ
from your_accounts_file import accounts, save_accounts  # Đảm bảo có

DAILY_VIEW_LIMIT = 1_000_000

def run_tiktok_boost(username, tiktok_link, target_quantity, chat_id):
    if username not in accounts:
        bot.send_message(chat_id, "❌ Tài khoản không tồn tại!")
        return

    if not accounts[username].get("allowed_tiktok"):
        bot.send_message(chat_id, "❌ Tài khoản chưa được cấp quyền buff TikTok.")
        return

    remaining = DAILY_VIEW_LIMIT - accounts[username].get("view_count", 0)
    if target_quantity > remaining:
        bot.send_message(chat_id, f"⚠️ Chỉ còn {remaining:,} view khả dụng hôm nay.")
        return

    total_views = 0
    updates = 0
    bot.send_message(chat_id, f"🚀 Bắt đầu tăng view cho:\n{tiktok_link}\n🎯 Số lượng: {target_quantity:,}")
    start_time = time.time()

    while total_views < target_quantity:
        views = min(random.randint(1, 5), target_quantity - total_views)
        total_views += views
        updates += 1
        accounts[username]['view_count'] += views
        save_accounts()

        now = datetime.now().strftime('%H:%M:%S')
        bot.send_message(chat_id, f"[{now}] +{views} view ➜ {total_views:,}/{target_quantity:,}")
        time.sleep(0.3)

        if accounts[username]['view_count'] >= DAILY_VIEW_LIMIT:
            bot.send_message(chat_id, "⚠️ Bạn đã đạt giới hạn view hôm nay!")
            break

    elapsed = round(time.time() - start_time, 2)
    bot.send_message(chat_id,
        f"✅ Hoàn tất!\n🎯 Tổng: {total_views:,} view\n🕐 Thời gian: {elapsed}s\n🔗 Link: {tiktok_link}")