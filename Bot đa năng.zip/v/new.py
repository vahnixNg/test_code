import random
from telebot import TeleBot

bot = TeleBot("8160438179:AAE_3vzKR9KCRu8_h7BFZk5AN5hdjUqpUfs")

fake_names = [
    "Lữ Bố Gánh Team", "Nobita OneShot", "Lạnh Lùng Thích Em", "Gáy Hộ Bạn", "Quỷ Vương FF",
    "Anh Đẹp Zai", "Cáo Già FF", "Lạc Lối Trong Em", "Rambo Siêu Nhân", "Tàng Hình OneShot"
]

ranks = ["Đồng", "Bạc", "Vàng", "Bạch Kim", "Kim Cương", "Huyền Thoại", "Thách Đấu"]

@bot.message_handler(commands=['uidffvip'])
def uidffvip(message):
    uid = str(random.randint(3000000000, 4000000000))
    name = random.choice(fake_names)
    level = random.randint(45, 90)
    kd = round(random.uniform(2.0, 6.5), 1)
    rank = random.choice(ranks)
    avatar_url = f"https://api.dicebear.com/7.x/thumbs/svg?seed={uid}"  # Avatar giả đẹp

    text = f"""🎮 UID Free Fire VIP:

👤 Tên: {name}
🆔 UID: {uid}
📶 Cấp độ: {level}
🏆 Rank: {rank}
🔫 K/D: {kd}
"""

    bot.send_photo(message.chat.id, avatar_url, caption=text)