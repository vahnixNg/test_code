from flask import Flask

app = Flask(__name__)

@app.route("/")
def profile():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Giới thiệu bản thân</title>
        <style>
            body { font-family: Arial; background: #f0f0f0; text-align: center; padding-top: 50px; }
            .card { background: white; padding: 30px; border-radius: 10px; width: 90%%; max-width: 400px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.2); }
            img { width: 120px; border-radius: 50%%; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="card">
            <img src="https://i.imgur.com/EVHnK4M.png" alt="Avatar">
            <h2>Giang Gaming</h2>
            <p>🧑‍💻 Lập trình viên Python, yêu thích MMO & Tool automation.</p>
            <p>📍 Việt Nam</p>
        </div>
    </body>
    </html>
    """

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1000)