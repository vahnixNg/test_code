#!/data/data/com.termux/files/usr/bin/bash

while true
do
    echo "▶️ Starting bot..."
    python bot.py
    echo "❌ Bot crashed. Restarting in 3 seconds..."
    sleep 3
done