import telebot
import requests
import os

TOKEN = "8160438179:AAE_3vzKR9KCRu8_h7BFZk5AN5hdjUqpUfs"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=["upload"])
def start_handler(message):
    bot.reply_to(message, "📤 Hãy gửi file bạn muốn upload, tối đa 1.5GB.")

@bot.message_handler(content_types=["document"])
def handle_file(message):
    try:
        file_info = bot.get_file(message.document.file_id)
        file_name = message.document.file_name
        file_path = file_info.file_path

        # 📥 Tải file từ Telegram về
        file_data = bot.download_file(file_path)
        with open(file_name, 'wb') as f:
            f.write(file_data)

        bot.reply_to(message, "⏳ Đang upload lên Gofile.io...")

        # 📤 Gửi file lên Gofile
        upload_res = requests.post(
            "https://api.gofile.io/uploadFile",
            files={"file": open(file_name, 'rb')}
        ).json()

        if upload_res["status"] == "ok":
            link = upload_res["data"]["downloadPage"]
            bot.send_message(message.chat.id, f"✅ File đã upload thành công:\n🔗 {link}")
        else:
            bot.send_message(message.chat.id, "❌ Upload thất bại.")

        os.remove(file_name)

    except Exception as e:
        bot.send_message(message.chat.id, f"⚠️ Lỗi: {e}")

bot.infinity_polling()